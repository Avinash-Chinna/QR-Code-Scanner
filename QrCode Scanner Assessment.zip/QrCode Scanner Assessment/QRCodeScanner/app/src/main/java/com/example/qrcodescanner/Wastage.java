package com.example.qrcodescanner;

public class Wastage {
    /* @Override
    public boolean onTouchEvent(MotionEvent event) {
        scaleGestureDetector.onTouchEvent(event);
        return true;
    }
//        scaleGestureDetector = new ScaleGestureDetector(this, new PinchZoomListener());

    public class PinchZoomListener extends ScaleGestureDetector.SimpleOnScaleGestureListener {
        @Override
        public boolean onScale(ScaleGestureDetector detector) {
            float gesture = detector.getScaleFactor();
            return true;
        }

        @Override
        public boolean onScaleBegin(ScaleGestureDetector detector) {
            return true;
        }

        @Override
        public void onScaleEnd(ScaleGestureDetector detector) {
            super.onScaleEnd(detector);
        }
    }*/
    /*  private void handleZoom(boolean isZoomIn, Camera camera) {
        Log.e("Camera", "");
        Camera.Parameters params = camera.getParameters();
        if (params.isZoomSupported()) {
            int maxZoom = params.getMaxZoom();
            int zoom = params.getZoom();
            if (isZoomIn && zoom < maxZoom) {
                Log.e("Camera", "zoom=" + zoom);
                zoom++;
            } else if (zoom > 0) {
                Log.e("Camera", "zoom=" + zoom);
                zoom--;
            }
            params.setZoom(zoom);
            camera.setParameters(params);
        } else {
            Log.i(TAG, "zoom not supported");
        }
    }
    public static void setZoom(Camera.Parameters parameters, double targetZoomRatio) {
        if (parameters.isZoomSupported()) {
            Integer zoom = indexOfClosestZoom(parameters, targetZoomRatio);
            if (zoom == null) {
                return;
            }
            if (parameters.getZoom() == zoom) {
                Log.i(Tag, "Zoom is already set to " + zoom);
            } else {
                Log.i(TAG, "Setting zoom to " + zoom);
                parameters.setZoom(zoom);
            }
        } else {
            Log.i(TAG, "Zoom is not supported");
        }
    }*/
}
//        seekBar = (SeekBar) findViewById(R.id.zoombar);
      /*  seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress,
                                          boolean fromUser) {

                Log.d(TAG, "progress:" + progress);
                if (camera.getParameters().isZoomSupported()) {
                    Camera.Parameters params = camera.getParameters();
                    int maxZoom = params.getMaxZoom();
                    int zoom = params.getZoom();
                    seekBar.setMax(maxZoom);
                    //zoom in
                    if (zoom < maxZoom)
                        zoom++;
                    //zoom out
                    if (zoom > 0)
                        zoom--;
                    params.setZoom(progress);
                    camera.setParameters(params);
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                // TODO Auto-generated method stub
                Log.d(TAG, "onStartTrackingTouch");
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                // TODO Auto-generated method stub
                Log.d(TAG, "onStartTrackingTouch");
            }

        });*/
